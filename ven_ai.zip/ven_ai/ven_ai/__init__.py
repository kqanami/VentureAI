from .celery import celery_app as celery

__all__ = ('celery',)
